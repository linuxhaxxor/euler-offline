"""
Problem 389
===========


   An unbiased single 4-sided die is thrown and its value, T, is noted.
   T unbiased 6-sided dice are thrown and their scores are added together.
   The sum, C, is noted.
   C unbiased 8-sided dice are thrown and their scores are added together.
   The sum, O, is noted.
   O unbiased 12-sided dice are thrown and their scores are added together.
   The sum, D, is noted.
   D unbiased 20-sided dice are thrown and their scores are added together.
   The sum, I, is noted.
   Find the variance of I, and give your answer rounded to 4 decimal places.


   Answer: 79a080d38b837547b975c97b44764dfb


"""
